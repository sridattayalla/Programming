#!/bin/bash
python *.py $*
